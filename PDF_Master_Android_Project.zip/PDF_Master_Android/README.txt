PDF MASTER — ANDROID STUDIO PROJECT

This is an Android WebView wrapper around the supplied PDF Master PWA.
The original HTML, manifest, service worker and icon are bundled locally in app/src/main/assets/www.

BUILD APK
1. Extract this ZIP on a computer.
2. Install Android Studio (current stable) and Android SDK Platform 35.
3. Open the extracted PDF_Master_Android folder in Android Studio.
4. Wait for Gradle sync to finish.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio shows the APK location when the build completes.

IMPORTANT
- This ZIP is an Android Studio source project, not a prebuilt APK.
- PDF.js and pdf-lib currently load from public CDNs, so internet is needed.
- File selection is supported in the Android WebView.
- AdMob is NOT active yet. Real ads require your AdMob account, app ID and ad unit IDs.
  Do not publish with test IDs or placeholder IDs. We can integrate ads after you create the AdMob account.
- Google Play Console can be set up later.

BUILD DIRECTLY USING YOUR ANDROID PHONE (GitHub Actions)
1. Create/sign in to a GitHub account in Chrome: https://github.com
2. Create a NEW PUBLIC or PRIVATE repository named PDF-Master-Android.
3. Extract this ZIP on your phone using Files > Downloads > ZIP > Extract.
4. In Chrome, open the new repository and use Add file > Upload files.
   Upload the extracted project contents (including the hidden .github/workflows folder).
   If your phone's file picker cannot select folders or hidden files, use GitHub's web editor
   or a cloud development environment; the workflow file must be at
   .github/workflows/build-apk.yml.
5. Commit the files to the main branch.
6. Open the repository's Actions tab, select "Build PDF Master APK", and tap Run workflow.
7. When it finishes successfully, open that workflow run, scroll to Artifacts,
   download PDF-Master-debug-APK, extract it, and tap app-debug.apk to install.
8. If Android blocks installation, allow Chrome/Files to install unknown apps for this APK.

This is an unsigned debug APK for personal testing, not a Play Store release. A signed
release build will be needed for publishing. Do not share APK builds from untrusted sources.
